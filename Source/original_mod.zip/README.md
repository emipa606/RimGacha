# RimGacha

Bring gacha games to the Rim!
Collect hundreds of gacha figures, hunt for the rarest of them all and arrange them in decorative collections to show off! Create fitting collections for even more beauty boost!

Built-in mod support for all animal and material mods. Get Jurassic Rimworld and start to collect dinosaur figures!

Can be added to existing saves.
